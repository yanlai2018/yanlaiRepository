create function getNaireQTypeChildList(rootId varchar(50))
  returns varchar(20000)
  BEGIN
       DECLARE sTemp VARCHAR(20000);
       DECLARE sTempChd VARCHAR(20000);
    
       SET sTemp = '$';
       SET sTempChd =cast(rootId as CHAR);
    
       WHILE sTempChd is not null DO
         SET sTemp = concat(sTemp,',',sTempChd);
         SELECT group_concat(ID) INTO sTempChd FROM zw_questionnaire_question_type where FIND_IN_SET(PARENT_ID,sTempChd)>0;
       END WHILE;
       RETURN sTemp;
     END;

