create function get_count(p_id varchar(100))
  returns tinyint
  BEGIN
		DECLARE p_count INT(11);
		SELECT COUNT('LINE_ID') into p_count from tb_line where PARENT_ID = p_id;
    RETURN p_count;
 END;

