create function getParentOrgNameList(rootId varchar(50))
  returns varchar(10000)
  BEGIN   
DECLARE fid varchar(10000) default '';  
DECLARE orgname varchar(10000) default '';   
DECLARE str varchar(10000) default '';   
WHILE rootId is not null  do   
    SET fid =(SELECT PARENT_ID FROM sys_org WHERE ID = rootId);
		SET orgname =(SELECT NAME FROM sys_org WHERE ID = rootId);   
    IF fid is not null THEN   
        SET str = concat(orgname, ',', str);   
        SET rootId = fid;   
    ELSE   
        SET rootId = fid;   
    END IF;   
END WHILE;   
return str;  
END;

